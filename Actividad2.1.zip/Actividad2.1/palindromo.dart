void main() {
  String esPalindromo(String cadena) {
    String NoCaracteres =
        cadena.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toLowerCase();
    //(RegExp(r'[^a-zA-Z0-9]') lo investigu, y funciona que puede leer todas los caracteres que no sean mayusculas, y digitos.

    bool esPalindromo =
        NoCaracteres == NoCaracteres.split('').reversed.join('');

    String mensaje = esPalindromo
        ? "La cadena es un palindromo"
        : "La cadena no es un palindromo";

    return mensaje;
  }

  var result1 = esPalindromo("Arenera");
  print(result1);

  var result2 = esPalindromo("Hola Mundo");
  print(result2);
}
